<?php
/**
 * Plugin Name: Hello Dolly
 * Version: 1.2.0-beta.1
 * Author: Test
 * Requires PHP: 7.4
 */
