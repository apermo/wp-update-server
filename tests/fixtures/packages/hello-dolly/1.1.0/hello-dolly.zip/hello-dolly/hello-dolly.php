<?php
/**
 * Plugin Name: Hello Dolly
 * Version: 1.1.0
 * Author: Test
 * Requires PHP: 7.4
 */
